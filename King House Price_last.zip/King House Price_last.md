```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
df=pd.read_csv('C:\\Users\\Tia Phan\\OneDrive\\Máy tính\\a\\House Price\\kc_house_data.csv')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>date</th>
      <th>price</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>sqft_living</th>
      <th>sqft_lot</th>
      <th>floors</th>
      <th>waterfront</th>
      <th>view</th>
      <th>...</th>
      <th>grade</th>
      <th>sqft_above</th>
      <th>sqft_basement</th>
      <th>yr_built</th>
      <th>yr_renovated</th>
      <th>zipcode</th>
      <th>lat</th>
      <th>long</th>
      <th>sqft_living15</th>
      <th>sqft_lot15</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7129300520</td>
      <td>20141013</td>
      <td>221900.0</td>
      <td>3</td>
      <td>1.00</td>
      <td>1180</td>
      <td>5650</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>7</td>
      <td>1180</td>
      <td>0</td>
      <td>1955</td>
      <td>0</td>
      <td>98178</td>
      <td>47.5112</td>
      <td>-122.257</td>
      <td>1340</td>
      <td>5650</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6414100192</td>
      <td>20141209</td>
      <td>538000.0</td>
      <td>3</td>
      <td>2.25</td>
      <td>2570</td>
      <td>7242</td>
      <td>2.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>7</td>
      <td>2170</td>
      <td>400</td>
      <td>1951</td>
      <td>1991</td>
      <td>98125</td>
      <td>47.7210</td>
      <td>-122.319</td>
      <td>1690</td>
      <td>7639</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5631500400</td>
      <td>20150225</td>
      <td>180000.0</td>
      <td>2</td>
      <td>1.00</td>
      <td>770</td>
      <td>10000</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>6</td>
      <td>770</td>
      <td>0</td>
      <td>1933</td>
      <td>0</td>
      <td>98028</td>
      <td>47.7379</td>
      <td>-122.233</td>
      <td>2720</td>
      <td>8062</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2487200875</td>
      <td>20141209</td>
      <td>604000.0</td>
      <td>4</td>
      <td>3.00</td>
      <td>1960</td>
      <td>5000</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>7</td>
      <td>1050</td>
      <td>910</td>
      <td>1965</td>
      <td>0</td>
      <td>98136</td>
      <td>47.5208</td>
      <td>-122.393</td>
      <td>1360</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1954400510</td>
      <td>20150218</td>
      <td>510000.0</td>
      <td>3</td>
      <td>2.00</td>
      <td>1680</td>
      <td>8080</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>8</td>
      <td>1680</td>
      <td>0</td>
      <td>1987</td>
      <td>0</td>
      <td>98074</td>
      <td>47.6168</td>
      <td>-122.045</td>
      <td>1800</td>
      <td>7503</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>




```python
df.drop(columns='id',inplace=True)
```


```python
df[['age']]=2022-df[['yr_built']]
```


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 21613 entries, 0 to 21612
    Data columns (total 22 columns):
     #   Column         Non-Null Count  Dtype  
    ---  ------         --------------  -----  
     0   date           21613 non-null  int64  
     1   price          21613 non-null  float64
     2   bedrooms       21613 non-null  int64  
     3   bathrooms      21613 non-null  float64
     4   sqft_living    21613 non-null  int64  
     5   sqft_lot       21613 non-null  int64  
     6   floors         21613 non-null  float64
     7   waterfront     21613 non-null  int64  
     8   view           21613 non-null  int64  
     9   condition      21613 non-null  int64  
     10  grade          21613 non-null  int64  
     11  sqft_above     21613 non-null  int64  
     12  sqft_basement  21613 non-null  int64  
     13  yr_built       21613 non-null  int64  
     14  yr_renovated   21613 non-null  int64  
     15  zipcode        21613 non-null  int64  
     16  lat            21613 non-null  float64
     17  long           21613 non-null  float64
     18  sqft_living15  21613 non-null  int64  
     19  sqft_lot15     21613 non-null  int64  
     20  age            21613 non-null  int64  
     21  renovated      21613 non-null  int64  
    dtypes: float64(5), int64(17)
    memory usage: 3.6 MB
    


```python
df['renovated']=df['yr_renovated'].apply(lambda x:0 if x==0 else 1)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
      <th>price</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>sqft_living</th>
      <th>sqft_lot</th>
      <th>floors</th>
      <th>waterfront</th>
      <th>view</th>
      <th>condition</th>
      <th>...</th>
      <th>sqft_basement</th>
      <th>yr_built</th>
      <th>yr_renovated</th>
      <th>zipcode</th>
      <th>lat</th>
      <th>long</th>
      <th>sqft_living15</th>
      <th>sqft_lot15</th>
      <th>age</th>
      <th>renovated</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>20141013</td>
      <td>221900.0</td>
      <td>3</td>
      <td>1.00</td>
      <td>1180</td>
      <td>5650</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>...</td>
      <td>0</td>
      <td>1955</td>
      <td>0</td>
      <td>98178</td>
      <td>47.5112</td>
      <td>-122.257</td>
      <td>1340</td>
      <td>5650</td>
      <td>67</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>20141209</td>
      <td>538000.0</td>
      <td>3</td>
      <td>2.25</td>
      <td>2570</td>
      <td>7242</td>
      <td>2.0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>...</td>
      <td>400</td>
      <td>1951</td>
      <td>1991</td>
      <td>98125</td>
      <td>47.7210</td>
      <td>-122.319</td>
      <td>1690</td>
      <td>7639</td>
      <td>71</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>20150225</td>
      <td>180000.0</td>
      <td>2</td>
      <td>1.00</td>
      <td>770</td>
      <td>10000</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>...</td>
      <td>0</td>
      <td>1933</td>
      <td>0</td>
      <td>98028</td>
      <td>47.7379</td>
      <td>-122.233</td>
      <td>2720</td>
      <td>8062</td>
      <td>89</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>20141209</td>
      <td>604000.0</td>
      <td>4</td>
      <td>3.00</td>
      <td>1960</td>
      <td>5000</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
      <td>...</td>
      <td>910</td>
      <td>1965</td>
      <td>0</td>
      <td>98136</td>
      <td>47.5208</td>
      <td>-122.393</td>
      <td>1360</td>
      <td>5000</td>
      <td>57</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20150218</td>
      <td>510000.0</td>
      <td>3</td>
      <td>2.00</td>
      <td>1680</td>
      <td>8080</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>...</td>
      <td>0</td>
      <td>1987</td>
      <td>0</td>
      <td>98074</td>
      <td>47.6168</td>
      <td>-122.045</td>
      <td>1800</td>
      <td>7503</td>
      <td>35</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 22 columns</p>
</div>




```python
age_price=df.groupby(['age']).sum()['price']
age_price
```




    age
    7       28878896.0
    8      382240111.0
    9      136398516.0
    10      89664287.0
    11      70804290.0
              ...     
    118     26274049.0
    119     22124077.0
    120     18176200.0
    121     16156142.0
    122     50593687.0
    Name: price, Length: 116, dtype: float64




```python
age=[age for age, df in df.groupby(['age'])]

plt.bar(age, age_price)
plt.xlabel('Age')
plt.ylabel('Price')
plt.title('Age vs Price')
plt.show()
```


    
![png](output_9_0.png)
    



```python
df.duplicate()[]
```


```python
df[['bedrooms']]=df[['bedrooms']].astype(int)
```


```python
df[df['bedrooms']==33]=df[df['bedrooms']==3]
```


```python
df.isnull().sum()
```




    id               1
    date             1
    price            1
    bedrooms         1
    bathrooms        1
    sqft_living      1
    sqft_lot         1
    floors           1
    waterfront       1
    view             1
    condition        1
    grade            1
    sqft_above       1
    sqft_basement    1
    yr_built         1
    yr_renovated     1
    zipcode          1
    lat              1
    long             1
    sqft_living15    1
    sqft_lot15       1
    age              1
    renovated        1
    dtype: int64




```python
df.dropna(inplace=True)
```


```python
df.isna().sum().sum()
```




    0




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
      <th>price</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>sqft_living</th>
      <th>sqft_lot</th>
      <th>floors</th>
      <th>waterfront</th>
      <th>view</th>
      <th>condition</th>
      <th>...</th>
      <th>sqft_basement</th>
      <th>yr_built</th>
      <th>yr_renovated</th>
      <th>zipcode</th>
      <th>lat</th>
      <th>long</th>
      <th>sqft_living15</th>
      <th>sqft_lot15</th>
      <th>age</th>
      <th>renovated</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>20141013.0</td>
      <td>221900.0</td>
      <td>3.0</td>
      <td>1.00</td>
      <td>1180.0</td>
      <td>5650.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>1955.0</td>
      <td>0.0</td>
      <td>98178.0</td>
      <td>47.5112</td>
      <td>-122.257</td>
      <td>1340.0</td>
      <td>5650.0</td>
      <td>67.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>20141209.0</td>
      <td>538000.0</td>
      <td>3.0</td>
      <td>2.25</td>
      <td>2570.0</td>
      <td>7242.0</td>
      <td>2.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>400.0</td>
      <td>1951.0</td>
      <td>1991.0</td>
      <td>98125.0</td>
      <td>47.7210</td>
      <td>-122.319</td>
      <td>1690.0</td>
      <td>7639.0</td>
      <td>71.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>20150225.0</td>
      <td>180000.0</td>
      <td>2.0</td>
      <td>1.00</td>
      <td>770.0</td>
      <td>10000.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>1933.0</td>
      <td>0.0</td>
      <td>98028.0</td>
      <td>47.7379</td>
      <td>-122.233</td>
      <td>2720.0</td>
      <td>8062.0</td>
      <td>89.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>20141209.0</td>
      <td>604000.0</td>
      <td>4.0</td>
      <td>3.00</td>
      <td>1960.0</td>
      <td>5000.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>5.0</td>
      <td>...</td>
      <td>910.0</td>
      <td>1965.0</td>
      <td>0.0</td>
      <td>98136.0</td>
      <td>47.5208</td>
      <td>-122.393</td>
      <td>1360.0</td>
      <td>5000.0</td>
      <td>57.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20150218.0</td>
      <td>510000.0</td>
      <td>3.0</td>
      <td>2.00</td>
      <td>1680.0</td>
      <td>8080.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>1987.0</td>
      <td>0.0</td>
      <td>98074.0</td>
      <td>47.6168</td>
      <td>-122.045</td>
      <td>1800.0</td>
      <td>7503.0</td>
      <td>35.0</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 22 columns</p>
</div>




```python
df.corr()['price'].sort_values(ascending=False)
```




    price            1.000000
    sqft_living      0.702055
    grade            0.667476
    sqft_above       0.605589
    sqft_living15    0.585399
    bathrooms        0.525144
    view             0.397352
    sqft_basement    0.323833
    bedrooms         0.315434
    lat              0.306914
    waterfront       0.266332
    floors           0.256803
    yr_renovated     0.126445
    renovated        0.126104
    sqft_lot         0.089658
    sqft_lot15       0.082460
    yr_built         0.053993
    condition        0.036366
    long             0.021582
    date             0.003021
    id              -0.016788
    zipcode         -0.053174
    age             -0.053993
    Name: price, dtype: float64




```python
plt.figure(figsize=(15,20))
sns.heatmap(df.corr())
```




    <AxesSubplot:>




    
![png](output_18_1.png)
    


# Lasso Regression

Lasso performs best when all numerical features are centered around 0 and have variance in the same order. If a feature has a variance that is orders of magnitude larger than others, it might dominate the objective function and make the estimator unable to learn from other features correctly as expected.
https://www.kirenz.com/post/2019-08-12-python-lasso-regression-auto/ 

To avoid data leakage, the standardization of numerical features should always be performed after data splitting and only from training data. Furthermore, we obtain all necessary statistics for our features (mean and standard deviation) from training data and also use them on test data. Note that we don’t standardize our dummy variables (which only have values of 0 or 1).

Tuning: https://www.kirenz.com/post/2019-08-12-python-lasso-regression-auto/


```python
from sklearn.linear_model import LassoCV
from sklearn.model_selection import RepeatedKFold
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
```

### Spliting data


```python
X=df.drop(['price'],axis=1)
y=df['price']
```

### Scaling data using StandardScaler from sklearn.preprocessing library


```python
scaler=StandardScaler().fit(X)
```


```python
X_scale=scaler.transform(X)
```


```python
## X_train=scaler.transform(X_train)
## X_test=scaler.transform(X_test)
```

### Scaling X_train, X_test using scaler.transform


```python
X_train,X_test,y_train,y_test=train_test_split(X_scale,y,test_size=0.2,random_state=2)
```


```python
X_train.shape, X_test.shape, y_train.shape, y_test.shape
```




    ((17289, 21), (4323, 21), (17289,), (4323,))



### Cross Validation


```python
cv=RepeatedKFold(n_splits=10,n_repeats=3,random_state=1)
```

### LassoCV


```python
from numpy import arange
ls=LassoCV(alphas=arange(0,0.01,1),cv=cv,n_jobs=-1)
```


```python
## Show best value of penalization chosen by cross validation:
##ls.alpha_
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    C:\Users\TIAPHA~1\AppData\Local\Temp/ipykernel_2976/2026378799.py in <module>
          1 ## Show best value of penalization chosen by cross validation:
    ----> 2 ls.alpha_
    

    AttributeError: 'LassoCV' object has no attribute 'alpha_'



```python
## ls_best=LassoCV(alphas=ls.alphas_,cv=cv,n_jobs=-1)
```


```python
ls.fit(X_train,y_train)
```

    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: UserWarning: Coordinate descent without L1 regularization may lead to unexpected results and is discouraged. Set l1_ratio > 0 to add L1 regularization.
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: UserWarning: Coordinate descent without L1 regularization may lead to unexpected results and is discouraged. Set l1_ratio > 0 to add L1 regularization.
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 324145605520878.75, tolerance: 217781414844.0715
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: UserWarning: Coordinate descent without L1 regularization may lead to unexpected results and is discouraged. Set l1_ratio > 0 to add L1 regularization.
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 313349794289066.5, tolerance: 212448533420.35535
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 317505415663920.5, tolerance: 210775345627.7458
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: UserWarning: Coordinate descent without L1 regularization may lead to unexpected results and is discouraged. Set l1_ratio > 0 to add L1 regularization.
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 312765458547617.75, tolerance: 210908419483.73923
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 301140483340724.0, tolerance: 202707843423.3902
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 320587523860923.0, tolerance: 213114590255.60724
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 321174972889078.25, tolerance: 213772244487.35565
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 320854844227761.75, tolerance: 214782706883.91357
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: UserWarning: Coordinate descent without L1 regularization may lead to unexpected results and is discouraged. Set l1_ratio > 0 to add L1 regularization.
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: UserWarning: Coordinate descent without L1 regularization may lead to unexpected results and is discouraged. Set l1_ratio > 0 to add L1 regularization.
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 321785653563811.5, tolerance: 214903715583.9504
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 317655568408589.25, tolerance: 211584865085.53693
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 308851243611782.25, tolerance: 206738923098.57516
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 317954959592534.0, tolerance: 211065712395.12152
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 318402474097343.25, tolerance: 213927572313.8939
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 307525462474956.5, tolerance: 205658165909.73575
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 317180898748100.75, tolerance: 214388204292.20352
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 324448761537723.25, tolerance: 217592926139.82562
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: UserWarning: Coordinate descent without L1 regularization may lead to unexpected results and is discouraged. Set l1_ratio > 0 to add L1 regularization.
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: UserWarning: Coordinate descent without L1 regularization may lead to unexpected results and is discouraged. Set l1_ratio > 0 to add L1 regularization.
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: UserWarning: Coordinate descent without L1 regularization may lead to unexpected results and is discouraged. Set l1_ratio > 0 to add L1 regularization.
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: UserWarning: Coordinate descent without L1 regularization may lead to unexpected results and is discouraged. Set l1_ratio > 0 to add L1 regularization.
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 310910030238806.75, tolerance: 208391637501.08398
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 317515872552196.0, tolerance: 213213367182.76474
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 309291277621523.25, tolerance: 206869403103.22125
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 314802709292790.0, tolerance: 213113799010.70514
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 317471938421046.0, tolerance: 212417970036.7621
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 312644519516142.0, tolerance: 210743389183.9856
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 318486174730172.25, tolerance: 210453335437.3325
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 310884320260331.5, tolerance: 209560218566.29553
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: UserWarning: Coordinate descent without L1 regularization may lead to unexpected results and is discouraged. Set l1_ratio > 0 to add L1 regularization.
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: UserWarning: Coordinate descent without L1 regularization may lead to unexpected results and is discouraged. Set l1_ratio > 0 to add L1 regularization.
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: UserWarning: Coordinate descent without L1 regularization may lead to unexpected results and is discouraged. Set l1_ratio > 0 to add L1 regularization.
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 309557082956118.0, tolerance: 208955115352.15112
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 305738569141265.25, tolerance: 209845026237.6254
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: UserWarning: Coordinate descent without L1 regularization may lead to unexpected results and is discouraged. Set l1_ratio > 0 to add L1 regularization.
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 320872942744291.5, tolerance: 212892358770.82715
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 320505345787589.75, tolerance: 213405448067.11182
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 318686292666689.25, tolerance: 211820528312.35092
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:634: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations. Duality gap: 320802214295648.75, tolerance: 213793532152.20657
      model = cd_fast.enet_coordinate_descent_gram(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:1771: UserWarning: With alpha=0, this algorithm does not converge well. You are advised to use the LinearRegression estimator
      model.fit(X, y)
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:648: UserWarning: Coordinate descent with no regularization may lead to unexpected results and is discouraged.
      model = cd_fast.enet_coordinate_descent(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\linear_model\_coordinate_descent.py:648: ConvergenceWarning: Objective did not converge. You might want to increase the number of iterations, check the scale of the features or consider increasing regularisation. Duality gap: 3.510e+14, tolerance: 2.351e+11 Linear regression models with null weight for the l1 regularization term are more efficiently fitted using one of the solvers implemented in sklearn.linear_model.Ridge/RidgeCV instead.
      model = cd_fast.enet_coordinate_descent(
    




<style>#sk-container-id-10 {color: black;background-color: white;}#sk-container-id-10 pre{padding: 0;}#sk-container-id-10 div.sk-toggleable {background-color: white;}#sk-container-id-10 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-10 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-10 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-10 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-10 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-10 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-10 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-10 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-10 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-10 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-10 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-10 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-10 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-10 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-10 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-10 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-10 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-10 div.sk-item {position: relative;z-index: 1;}#sk-container-id-10 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-10 div.sk-item::before, #sk-container-id-10 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-10 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-10 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-10 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-10 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-10 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-10 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-10 div.sk-label-container {text-align: center;}#sk-container-id-10 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-10 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-10" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LassoCV(alphas=array([0.]),
        cv=RepeatedKFold(n_repeats=3, n_splits=10, random_state=1), n_jobs=-1)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-10" type="checkbox" checked><label for="sk-estimator-id-10" class="sk-toggleable__label sk-toggleable__label-arrow">LassoCV</label><div class="sk-toggleable__content"><pre>LassoCV(alphas=array([0.]),
        cv=RepeatedKFold(n_repeats=3, n_splits=10, random_state=1), n_jobs=-1)</pre></div></div></div></div></div>




```python
ls_predict=ls_best.predict(X_test)
```


```python
from sklearn import metrics
```


```python
ls_mse=metrics.mean_squared_error(y_test,ls_predict)
```


```python
ls_mae=metrics.mean_absolute_error(y_test,ls_predict)
```


```python
import math
```


```python
ls_rmse=math.sqrt(ls_mse)
```


```python
print('MSE is:',round(ls_mse,2))
print('RMSE is:',round(ls_rmse,2))
print('MAE is:',round(ls_mae,2))
print('r2 is:',metrics.r2_score(y_test,ls_predict))
```

    MSE is: 38735410323.02
    RMSE is: 196813.14
    MAE is: 125074.09
    r2 is: 0.7038959531794409
    


```python
print("Accuracy is:", ls.score(X_test,y_test))
```

    Accuracy is: 0.7038105803098154
    


```python
pd.DataFrame({'Actual':y_test,'Predict':ls_predict})
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Predict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>12183</th>
      <td>710500.0</td>
      <td>7.624550e+05</td>
    </tr>
    <tr>
      <th>18992</th>
      <td>1510000.0</td>
      <td>1.321793e+06</td>
    </tr>
    <tr>
      <th>8370</th>
      <td>425000.0</td>
      <td>5.284292e+05</td>
    </tr>
    <tr>
      <th>9210</th>
      <td>350000.0</td>
      <td>2.269667e+05</td>
    </tr>
    <tr>
      <th>21107</th>
      <td>333490.0</td>
      <td>3.713577e+05</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>18518</th>
      <td>319000.0</td>
      <td>3.214385e+05</td>
    </tr>
    <tr>
      <th>10449</th>
      <td>650000.0</td>
      <td>8.140620e+05</td>
    </tr>
    <tr>
      <th>1080</th>
      <td>208000.0</td>
      <td>2.425789e+05</td>
    </tr>
    <tr>
      <th>18960</th>
      <td>480000.0</td>
      <td>2.730884e+05</td>
    </tr>
    <tr>
      <th>21594</th>
      <td>350000.0</td>
      <td>4.279341e+05</td>
    </tr>
  </tbody>
</table>
<p>4323 rows × 2 columns</p>
</div>



## Plot


```python
plt.scatter(y_test,ls_predict)
```




    <matplotlib.collections.PathCollection at 0x155cac4a160>




    
![png](output_50_1.png)
    



```python
fig, ax = plt.subplots()
ax.scatter(y_test, ls_predict)
ax.plot([y.min(), y.max()], [y.min(), y.max()], 'k-', lw=1,color='red')
ax.set_xlabel('LassoCV Prediction')
ax.set_ylabel('Actual Price')
plt.legend(['Line of best fit','House Price'],loc='upper right')
plt.show()
```

    C:\Users\TIAPHA~1\AppData\Local\Temp/ipykernel_2976/3407199561.py:3: UserWarning: color is redundantly defined by the 'color' keyword argument and the fmt string "k-" (-> color='k'). The keyword argument will take precedence.
      ax.plot([y.min(), y.max()], [y.min(), y.max()], 'k-', lw=1,color='red')
    


    
![png](output_51_1.png)
    



```python
import statsmodels.api as sm
```


```python
from sklearn.feature_selection import RFE
```


```python
rfe = RFE(ls, 3)
rfe = rfe.fit(X_train, y_train)
rfe_ = X_train.columns[rfe.support_]
rfe_
```


    ---------------------------------------------------------------------------

    TypeError                                 Traceback (most recent call last)

    C:\Users\TIAPHA~1\AppData\Local\Temp/ipykernel_2976/205136012.py in <module>
    ----> 1 rfe = RFE(ls, 3)
          2 rfe = rfe.fit(X_train, y_train)
          3 rfe_ = X_train.columns[rfe.support_]
          4 rfe_
    

    TypeError: __init__() takes 2 positional arguments but 3 were given



```python
def build_model(X,y):
    X = sm.add_constant(X) 
    #Ading constant
    lm = sm.OLS(y,X).fit() 
    print(lm.summary()) #summary
    return X
def checkVIF(X):   
    vif = pd.DataFrame()
    vif['Features'] = X.columns
    vif['VIF'] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]
    vif['VIF'] = round(vif['VIF'], 2)
    vif = vif.sort_values(by = "VIF", ascending = False)
    return(vif)
```


```python
x_train_new = build_model(X_train,y_train)
```

                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:                  price   R-squared:                       0.702
    Model:                            OLS   Adj. R-squared:                  0.702
    Method:                 Least Squares   F-statistic:                     2037.
    Date:                Wed, 08 Jun 2022   Prob (F-statistic):               0.00
    Time:                        13:36:53   Log-Likelihood:            -2.3567e+05
    No. Observations:               17289   AIC:                         4.714e+05
    Df Residuals:                   17268   BIC:                         4.715e+05
    Df Model:                          20                                         
    Covariance Type:            nonrobust                                         
    ==============================================================================
                     coef    std err          t      P>|t|      [0.025      0.975]
    ------------------------------------------------------------------------------
    const       5.414e+05   1531.145    353.596      0.000    5.38e+05    5.44e+05
    x1         -3587.0711   1553.148     -2.310      0.021   -6631.399    -542.744
    x2          1.347e+04   1536.321      8.766      0.000    1.05e+04    1.65e+04
    x3         -3.747e+04   2001.982    -18.719      0.000   -4.14e+04   -3.36e+04
    x4          3.034e+04   2808.840     10.801      0.000    2.48e+04    3.58e+04
    x5          8.373e+04   1775.569     47.156      0.000    8.02e+04    8.72e+04
    x6          2182.6896   2198.511      0.993      0.321   -2126.614    6491.993
    x7          6064.5902   2169.080      2.796      0.005    1812.973    1.03e+04
    x8          5.169e+04   1679.667     30.775      0.000    4.84e+04     5.5e+04
    x9           3.86e+04   1836.623     21.017      0.000     3.5e+04    4.22e+04
    x10         1.968e+04   1717.515     11.457      0.000    1.63e+04     2.3e+04
    x11         1.124e+05   2840.933     39.549      0.000    1.07e+05    1.18e+05
    x12         7.756e+04   1899.879     40.822      0.000    7.38e+04    8.13e+04
    x13         2.899e+04   1754.464     16.526      0.000    2.56e+04    3.24e+04
    x14        -3.914e+04   1191.593    -32.846      0.000   -4.15e+04   -3.68e+04
    x15         1.489e+06   1.93e+05      7.732      0.000    1.11e+06    1.87e+06
    x16        -3.309e+04   1971.310    -16.788      0.000    -3.7e+04   -2.92e+04
    x17           8.4e+04   1660.805     50.580      0.000    8.07e+04    8.73e+04
    x18         -3.09e+04   2075.043    -14.892      0.000    -3.5e+04   -2.68e+04
    x19          1.63e+04   2640.794      6.174      0.000    1.11e+04    2.15e+04
    x20        -9610.3885   2210.774     -4.347      0.000   -1.39e+04   -5277.047
    x21         3.914e+04   1191.593     32.846      0.000    3.68e+04    4.15e+04
    x22        -1.481e+06   1.93e+05     -7.688      0.000   -1.86e+06    -1.1e+06
    ==============================================================================
    Omnibus:                    15081.730   Durbin-Watson:                   2.017
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):          1753035.184
    Skew:                           3.671   Prob(JB):                         0.00
    Kurtosis:                      51.781   Cond. No.                     1.37e+16
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
    [2] The smallest eigenvalue is 5.2e-28. This might indicate that there are
    strong multicollinearity problems or that the design matrix is singular.
    


```python
checkVIF(x_train_new)
```


    ---------------------------------------------------------------------------

    AttributeError                            Traceback (most recent call last)

    C:\Users\TIAPHA~1\AppData\Local\Temp/ipykernel_2976/3702065917.py in <module>
    ----> 1 checkVIF(x_train_new)
    

    C:\Users\TIAPHA~1\AppData\Local\Temp/ipykernel_2976/1579959365.py in checkVIF(X)
          7 def checkVIF(X):
          8     vif = pd.DataFrame()
    ----> 9     vif['Features'] = X.columns
         10     vif['VIF'] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]
         11     vif['VIF'] = round(vif['VIF'], 2)
    

    AttributeError: 'numpy.ndarray' object has no attribute 'columns'


# XGBoost


```python
import xgboost as xgb
```


```python
xg=xgb.XGBRegressor()
```


```python
from sklearn.experimental import enable_halving_search_cv
from sklearn.model_selection import HalvingGridSearchCV
```


```python
param={'n_estimator':[5,10,12],
      'max_depth':[5,6,7],
      'learning_rate':[0.1,0.3,0.5]}
```


```python
model_grid=HalvingGridSearchCV(estimator=xg,param_grid={'n_estimator':[5,10,12],
      'max_depth':[5,6,7],
      'learning_rate':[0.1,0.3,0.5]},cv=3,n_jobs=-1,scoring=r2_score)
```


```python
model_grid_result=model_grid.fit(X_train,y_train)
```

    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\model_selection\_search.py:953: UserWarning: One or more of the test scores are non-finite: [nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan
     nan nan nan nan nan nan nan nan nan]
      warnings.warn(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\model_selection\_search.py:953: UserWarning: One or more of the train scores are non-finite: [nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan
     nan nan nan nan nan nan nan nan nan]
      warnings.warn(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\model_selection\_search.py:953: UserWarning: One or more of the test scores are non-finite: [nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan
     nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan]
      warnings.warn(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\model_selection\_search.py:953: UserWarning: One or more of the train scores are non-finite: [nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan
     nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan]
      warnings.warn(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\model_selection\_search.py:953: UserWarning: One or more of the test scores are non-finite: [nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan
     nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan
     nan nan nan]
      warnings.warn(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\model_selection\_search.py:953: UserWarning: One or more of the train scores are non-finite: [nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan
     nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan
     nan nan nan]
      warnings.warn(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\model_selection\_search.py:953: UserWarning: One or more of the test scores are non-finite: [nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan
     nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan
     nan nan nan nan]
      warnings.warn(
    C:\Users\Tia Phan\anaconda3\lib\site-packages\sklearn\model_selection\_search.py:953: UserWarning: One or more of the train scores are non-finite: [nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan
     nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan nan
     nan nan nan nan]
      warnings.warn(
    

    [16:14:09] WARNING: C:/Users/Administrator/workspace/xgboost-win64_release_1.6.0/src/learner.cc:627: 
    Parameters: { "n_estimator" } might not be used.
    
      This could be a false alarm, with some parameters getting used by language bindings but
      then being mistakenly passed down to XGBoost core, or some parameter actually being used
      but getting flagged wrongly here. Please open an issue if you find any such cases.
    
    
    


```python
model_grid_result.best_params_
```




    {'learning_rate': 0.5, 'max_depth': 7, 'n_estimator': 12}




```python
model_grid_result.best_score_
```




    nan




```python
xg=xgb.XGBRegressor(learning_rate= 0.5, max_depth= 7, n_estimator= 12, cv=50)
```


```python
xg.fit(X_train,y_train)
```

    [16:14:19] WARNING: C:/Users/Administrator/workspace/xgboost-win64_release_1.6.0/src/learner.cc:627: 
    Parameters: { "cv", "n_estimator" } might not be used.
    
      This could be a false alarm, with some parameters getting used by language bindings but
      then being mistakenly passed down to XGBoost core, or some parameter actually being used
      but getting flagged wrongly here. Please open an issue if you find any such cases.
    
    
    




<style>#sk-container-id-11 {color: black;background-color: white;}#sk-container-id-11 pre{padding: 0;}#sk-container-id-11 div.sk-toggleable {background-color: white;}#sk-container-id-11 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-11 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-11 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-11 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-11 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-11 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-11 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-11 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-11 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-11 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-11 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-11 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-11 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-11 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-11 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-11 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-11 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-11 div.sk-item {position: relative;z-index: 1;}#sk-container-id-11 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-11 div.sk-item::before, #sk-container-id-11 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-11 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-11 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-11 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-11 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-11 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-11 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-11 div.sk-label-container {text-align: center;}#sk-container-id-11 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-11 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-11" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>XGBRegressor(base_score=0.5, booster=&#x27;gbtree&#x27;, callbacks=None,
             colsample_bylevel=1, colsample_bynode=1, colsample_bytree=1, cv=50,
             early_stopping_rounds=None, enable_categorical=False,
             eval_metric=None, gamma=0, gpu_id=-1, grow_policy=&#x27;depthwise&#x27;,
             importance_type=None, interaction_constraints=&#x27;&#x27;,
             learning_rate=0.5, max_bin=256, max_cat_to_onehot=4,
             max_delta_step=0, max_depth=7, max_leaves=0, min_child_weight=1,
             missing=nan, monotone_constraints=&#x27;()&#x27;, n_estimator=12,
             n_estimators=100, n_jobs=0, num_parallel_tree=1, predictor=&#x27;auto&#x27;,
             random_state=0, ...)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-11" type="checkbox" checked><label for="sk-estimator-id-11" class="sk-toggleable__label sk-toggleable__label-arrow">XGBRegressor</label><div class="sk-toggleable__content"><pre>XGBRegressor(base_score=0.5, booster=&#x27;gbtree&#x27;, callbacks=None,
             colsample_bylevel=1, colsample_bynode=1, colsample_bytree=1, cv=50,
             early_stopping_rounds=None, enable_categorical=False,
             eval_metric=None, gamma=0, gpu_id=-1, grow_policy=&#x27;depthwise&#x27;,
             importance_type=None, interaction_constraints=&#x27;&#x27;,
             learning_rate=0.5, max_bin=256, max_cat_to_onehot=4,
             max_delta_step=0, max_depth=7, max_leaves=0, min_child_weight=1,
             missing=nan, monotone_constraints=&#x27;()&#x27;, n_estimator=12,
             n_estimators=100, n_jobs=0, num_parallel_tree=1, predictor=&#x27;auto&#x27;,
             random_state=0, ...)</pre></div></div></div></div></div>




```python
xg_predict=xg.predict(X_test)
```


```python
xg_mse=metrics.mean_squared_error(y_test,xg_predict)
```


```python
xg_rmse=math.sqrt(xg_mse)
```


```python
xg_mae=metrics.mean_absolute_error(y_test,xg_predict)
```


```python
print('MSE:',round(xg_mse,2))
print('RMSE:',round(xg_rmse,2))
print('MAE:',round(xg_mae,2))
```

    MSE: 14888762423.53
    RMSE: 122019.52
    MAE: 71109.72
    


```python
model_grid_improve=HalvingGridSearchCV(estimator=xgb.XGBRegressor(),
                                      param_grid={'gamma':[0.1,0,1],
                                                  'n_estimator':[20,12,14],
                                                 'colsample_bytree':[1,0]},
                                      cv=5,n_jobs=-1,verbose=3)
```


```python
model_grid_improve_result=model_grid_improve.fit(X_train,y_train)
```

    n_iterations: 3
    n_required_iterations: 3
    n_possible_iterations: 3
    min_resources_: 1921
    max_resources_: 17289
    aggressive_elimination: False
    factor: 3
    ----------
    iter: 0
    n_candidates: 18
    n_resources: 1921
    Fitting 5 folds for each of 18 candidates, totalling 90 fits
    ----------
    iter: 1
    n_candidates: 6
    n_resources: 5763
    Fitting 5 folds for each of 6 candidates, totalling 30 fits
    ----------
    iter: 2
    n_candidates: 2
    n_resources: 17289
    Fitting 5 folds for each of 2 candidates, totalling 10 fits
    [14:32:02] WARNING: C:/Users/Administrator/workspace/xgboost-win64_release_1.6.0/src/learner.cc:627: 
    Parameters: { "n_estimator" } might not be used.
    
      This could be a false alarm, with some parameters getting used by language bindings but
      then being mistakenly passed down to XGBoost core, or some parameter actually being used
      but getting flagged wrongly here. Please open an issue if you find any such cases.
    
    
    


```python
model_grid_improve_result.best_params_
```




    {'colsample_bytree': 1, 'gamma': 1, 'n_estimator': 12}




```python
xg_tune=xgb.XGBRegressor(colsample_bytree= 1, gamma= 1, n_estimator= 12,learning_rate= 0.5, max_depth= 7, cv=50)
```


```python
xg_tune.fit(X_train,y_train)
```

    [14:33:59] WARNING: C:/Users/Administrator/workspace/xgboost-win64_release_1.6.0/src/learner.cc:627: 
    Parameters: { "cv", "n_estimator" } might not be used.
    
      This could be a false alarm, with some parameters getting used by language bindings but
      then being mistakenly passed down to XGBoost core, or some parameter actually being used
      but getting flagged wrongly here. Please open an issue if you find any such cases.
    
    
    




<style>#sk-container-id-7 {color: black;background-color: white;}#sk-container-id-7 pre{padding: 0;}#sk-container-id-7 div.sk-toggleable {background-color: white;}#sk-container-id-7 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-7 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-7 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-7 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-7 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-7 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-7 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-7 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-7 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-7 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-7 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-7 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-7 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-7 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-7 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-7 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-7 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-7 div.sk-item {position: relative;z-index: 1;}#sk-container-id-7 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-7 div.sk-item::before, #sk-container-id-7 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-7 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-7 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-7 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-7 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-7 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-7 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-7 div.sk-label-container {text-align: center;}#sk-container-id-7 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-7 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-7" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>XGBRegressor(base_score=0.5, booster=&#x27;gbtree&#x27;, callbacks=None,
             colsample_bylevel=1, colsample_bynode=1, colsample_bytree=1, cv=50,
             early_stopping_rounds=None, enable_categorical=False,
             eval_metric=None, gamma=1, gpu_id=-1, grow_policy=&#x27;depthwise&#x27;,
             importance_type=None, interaction_constraints=&#x27;&#x27;,
             learning_rate=0.5, max_bin=256, max_cat_to_onehot=4,
             max_delta_step=0, max_depth=7, max_leaves=0, min_child_weight=1,
             missing=nan, monotone_constraints=&#x27;()&#x27;, n_estimator=12,
             n_estimators=100, n_jobs=0, num_parallel_tree=1, predictor=&#x27;auto&#x27;,
             random_state=0, ...)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-7" type="checkbox" checked><label for="sk-estimator-id-7" class="sk-toggleable__label sk-toggleable__label-arrow">XGBRegressor</label><div class="sk-toggleable__content"><pre>XGBRegressor(base_score=0.5, booster=&#x27;gbtree&#x27;, callbacks=None,
             colsample_bylevel=1, colsample_bynode=1, colsample_bytree=1, cv=50,
             early_stopping_rounds=None, enable_categorical=False,
             eval_metric=None, gamma=1, gpu_id=-1, grow_policy=&#x27;depthwise&#x27;,
             importance_type=None, interaction_constraints=&#x27;&#x27;,
             learning_rate=0.5, max_bin=256, max_cat_to_onehot=4,
             max_delta_step=0, max_depth=7, max_leaves=0, min_child_weight=1,
             missing=nan, monotone_constraints=&#x27;()&#x27;, n_estimator=12,
             n_estimators=100, n_jobs=0, num_parallel_tree=1, predictor=&#x27;auto&#x27;,
             random_state=0, ...)</pre></div></div></div></div></div>




```python
xg_tune_predict=xg_tune.predict(X_test)
```


```python
xg_tune_mse=metrics.mean_squared_error(y_test,xg_tune_predict)
xg_tune_rmse=math.sqrt(xg_tune_mse)
xg_tune_mae=metrics.mean_absolute_error(y_test,xg_tune_predict)
```


```python
print('Tune MSE:',round(xg_tune_mse,1))
print('Tune RMSE:',round(xg_tune_rmse,1))
print('Tune MAE:',round(xg_tune_mae,1))
```

    Tune MSE: 14888762423.5
    Tune RMSE: 122019.5
    Tune MAE: 71109.7
    


```python
print("Accuracy is:", xg_tune.score(X_test,y_test))
```

    Accuracy is: 0.8841682350908057
    


```python
pd.DataFrame({'Actual':y_test,'Predict':xg_tune_predict})
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Predict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>12183</th>
      <td>710500.0</td>
      <td>7.014739e+05</td>
    </tr>
    <tr>
      <th>18992</th>
      <td>1510000.0</td>
      <td>1.459566e+06</td>
    </tr>
    <tr>
      <th>8370</th>
      <td>425000.0</td>
      <td>3.840355e+05</td>
    </tr>
    <tr>
      <th>9210</th>
      <td>350000.0</td>
      <td>3.311641e+05</td>
    </tr>
    <tr>
      <th>21107</th>
      <td>333490.0</td>
      <td>3.732715e+05</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>18518</th>
      <td>319000.0</td>
      <td>3.307185e+05</td>
    </tr>
    <tr>
      <th>10449</th>
      <td>650000.0</td>
      <td>7.810015e+05</td>
    </tr>
    <tr>
      <th>1080</th>
      <td>208000.0</td>
      <td>2.231431e+05</td>
    </tr>
    <tr>
      <th>18960</th>
      <td>480000.0</td>
      <td>3.797287e+05</td>
    </tr>
    <tr>
      <th>21594</th>
      <td>350000.0</td>
      <td>3.567781e+05</td>
    </tr>
  </tbody>
</table>
<p>4323 rows × 2 columns</p>
</div>




```python
pd.DataFrame({'Actual':y_test,'Predict':xg_predict})
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Predict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>12183</th>
      <td>710500.0</td>
      <td>7.014739e+05</td>
    </tr>
    <tr>
      <th>18992</th>
      <td>1510000.0</td>
      <td>1.459566e+06</td>
    </tr>
    <tr>
      <th>8370</th>
      <td>425000.0</td>
      <td>3.840355e+05</td>
    </tr>
    <tr>
      <th>9210</th>
      <td>350000.0</td>
      <td>3.311641e+05</td>
    </tr>
    <tr>
      <th>21107</th>
      <td>333490.0</td>
      <td>3.732715e+05</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>18518</th>
      <td>319000.0</td>
      <td>3.307185e+05</td>
    </tr>
    <tr>
      <th>10449</th>
      <td>650000.0</td>
      <td>7.810015e+05</td>
    </tr>
    <tr>
      <th>1080</th>
      <td>208000.0</td>
      <td>2.231431e+05</td>
    </tr>
    <tr>
      <th>18960</th>
      <td>480000.0</td>
      <td>3.797287e+05</td>
    </tr>
    <tr>
      <th>21594</th>
      <td>350000.0</td>
      <td>3.567781e+05</td>
    </tr>
  </tbody>
</table>
<p>4323 rows × 2 columns</p>
</div>



The model is still remaining the same after adding gamma, colsample_bytree


```python
fig,ax=plt.subplots()
ax.scatter(y_test,xg_predict,label='Housing Price')
ax.plot([y.min(),y.max()],[y.min(),y.max()],'k-',lw=1,color='red',label='Line of Best Fit')
ax.set_xlabel('XGBoost Prediction')
ax.set_ylabel('Actual Price')
plt.legend()
plt.show()
```

    C:\Users\TIAPHA~1\AppData\Local\Temp/ipykernel_2976/2619035461.py:3: UserWarning: color is redundantly defined by the 'color' keyword argument and the fmt string "k-" (-> color='k'). The keyword argument will take precedence.
      ax.plot([y.min(),y.max()],[y.min(),y.max()],'k-',lw=1,color='red',label='Line of Best Fit')
    


    
![png](output_86_1.png)
    



```python
x_ax = range(len(y_test))
plt.scatter(x_ax, y_test, s=5, color="blue", label="original")
plt.plot(x_ax, xg_predict, lw=0.8, color="red", label="predicted")
plt.legend()
plt.show()
```


    
![png](output_87_0.png)
    


# Neural Network


```python
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import *
```


```python
import tensorflow as tf
```


```python
neunet=Sequential()
```


```python
neunet.add(Dense(1000,activation='relu',input_dim=10))
neunet.add(Dense(800,activation='relu'))
neunet.add(Dense(500,activation='relu'))
neunet.add(Dense(200,activation='relu'))
neunet.add(Dense(100,activation='relu'))
neunet.add(Dense(1))
neunet.compile(optimizer='adam',loss='mse',metrics=[tf.keras.metrics.RootMeanSquaredError(name='rmse'),'mae'])
```


```python
neu=neunet.fit(X_train,y_train,epochs=100)
```

    Epoch 1/100
    


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    C:\Users\TIAPHA~1\AppData\Local\Temp/ipykernel_2976/3570515265.py in <module>
    ----> 1 neu=neunet.fit(X_train,y_train,epochs=100)
    

    ~\anaconda3\lib\site-packages\keras\utils\traceback_utils.py in error_handler(*args, **kwargs)
         65     except Exception as e:  # pylint: disable=broad-except
         66       filtered_tb = _process_traceback_frames(e.__traceback__)
    ---> 67       raise e.with_traceback(filtered_tb) from None
         68     finally:
         69       del filtered_tb
    

    ~\anaconda3\lib\site-packages\keras\engine\training.py in tf__train_function(iterator)
         13                 try:
         14                     do_return = True
    ---> 15                     retval_ = ag__.converted_call(ag__.ld(step_function), (ag__.ld(self), ag__.ld(iterator)), None, fscope)
         16                 except:
         17                     do_return = False
    

    ValueError: in user code:
    
        File "C:\Users\Tia Phan\anaconda3\lib\site-packages\keras\engine\training.py", line 1051, in train_function  *
            return step_function(self, iterator)
        File "C:\Users\Tia Phan\anaconda3\lib\site-packages\keras\engine\training.py", line 1040, in step_function  **
            outputs = model.distribute_strategy.run(run_step, args=(data,))
        File "C:\Users\Tia Phan\anaconda3\lib\site-packages\keras\engine\training.py", line 1030, in run_step  **
            outputs = model.train_step(data)
        File "C:\Users\Tia Phan\anaconda3\lib\site-packages\keras\engine\training.py", line 889, in train_step
            y_pred = self(x, training=True)
        File "C:\Users\Tia Phan\anaconda3\lib\site-packages\keras\utils\traceback_utils.py", line 67, in error_handler
            raise e.with_traceback(filtered_tb) from None
        File "C:\Users\Tia Phan\anaconda3\lib\site-packages\keras\engine\input_spec.py", line 264, in assert_input_compatibility
            raise ValueError(f'Input {input_index} of layer "{layer_name}" is '
    
        ValueError: Input 0 of layer "sequential_1" is incompatible with the layer: expected shape=(None, 10), found shape=(None, 22)
    



```python
print(X_train.shape,X_test.shape,y_train.shape,y_test.shape)
```

    (17289, 22) (4323, 22) (17289,) (4323,)
    

## Random Forest
#### https://www.askpython.com/python/examples/random-forest-regression#:~:text=What%20is%20Random%20Forest%20Regression%3F%20Steps%20to%20perform,regression%20to%20dataset%204.%20Visualizing%20the%20result%208.


```python
from sklearn import ensemble
```


```python
from sklearn.ensemble import RandomForestRegressor
```


```python
rfg=RandomForestRegressor(n_estimators=10, random_state=1)  #n_estimator=10: build 10 trees in a forest
```


```python
rfg.fit(X_train,y_train)
```




<style>#sk-container-id-12 {color: black;background-color: white;}#sk-container-id-12 pre{padding: 0;}#sk-container-id-12 div.sk-toggleable {background-color: white;}#sk-container-id-12 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-12 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-12 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-12 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-12 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-12 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-12 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-12 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-12 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-12 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-12 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-12 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-12 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-12 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-12 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-12 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-12 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-12 div.sk-item {position: relative;z-index: 1;}#sk-container-id-12 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-12 div.sk-item::before, #sk-container-id-12 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-12 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-12 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-12 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-12 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-12 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-12 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-12 div.sk-label-container {text-align: center;}#sk-container-id-12 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-12 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-12" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestRegressor(n_estimators=10, random_state=1)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-12" type="checkbox" checked><label for="sk-estimator-id-12" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestRegressor</label><div class="sk-toggleable__content"><pre>RandomForestRegressor(n_estimators=10, random_state=1)</pre></div></div></div></div></div>




```python
rfg_predict=rfg.predict(X_test)
```


```python
rfg_mse=metrics.mean_squared_error(y_test,rfg_predict)
```


```python
rfg_rmse=math.sqrt(rfg_mse)
```


```python
rfg_mae=metrics.mean_absolute_error(y_test,rfg_predict)
```


```python
print("MSE is:",round(rfg_mse,1))
print("RMSE is:",round(rfg_rmse,2))
print("MAE is:", round(rfg_mae,2))
```

    MSE is: 16361106708.9
    RMSE is: 127910.54
    MAE is: 70829.91
    


```python
print("Accuracy is:", rfg.score(X_test,y_test)*100)
```

    Accuracy is: 87.49312356167766
    


```python
fig, ax =plt.subplots()
ax.scatter(y_test,rfg_predict, label='Housing Price')
ax.plot([y.min(),y.max()],[y.min(),y.max()],'k-', lw=1, color='red', label='Line of best fit')
plt.legend(loc='upper right')
ax.set_xlabel("Random Forest Prediction")
ax.set_ylabel("Actual Price")
```

    C:\Users\TIAPHA~1\AppData\Local\Temp/ipykernel_2976/3110158454.py:3: UserWarning: color is redundantly defined by the 'color' keyword argument and the fmt string "k-" (-> color='k'). The keyword argument will take precedence.
      ax.plot([y.min(),y.max()],[y.min(),y.max()],'k-', lw=1, color='red', label='Line of best fit')
    




    Text(0, 0.5, 'Actual Price')




    
![png](output_106_2.png)
    



```python
RandomForestRegressor().get_params()
```




    {'bootstrap': True,
     'ccp_alpha': 0.0,
     'criterion': 'squared_error',
     'max_depth': None,
     'max_features': 1.0,
     'max_leaf_nodes': None,
     'max_samples': None,
     'min_impurity_decrease': 0.0,
     'min_samples_leaf': 1,
     'min_samples_split': 2,
     'min_weight_fraction_leaf': 0.0,
     'n_estimators': 100,
     'n_jobs': None,
     'oob_score': False,
     'random_state': None,
     'verbose': 0,
     'warm_start': False}




```python
n_estimators=list(range(10,220,50))
max_depth_list=list(range(5,41,10))
max_depth_list.append(None)
min_samples_split_list=[x/1000 for x in list(range(5,41,10))]
min_samples_leaf_list=[x/1000 for x in list (range(5,41,10))]
max_features_list=['sqrt','log2']

params_grid={'n_estimators':n_estimators,
            'max_depth':max_depth_list,
            'min_samples_split':min_samples_split_list,
            'min_samples_leaf':min_samples_leaf_list,
            'max_features':max_features_list
}
num_combinations=1
for k in params_grid.keys(): num_combinations *= len(params_grid[k])

print('Number of combinations=', num_combinations)
params_grid
```

    Number of combinations= 800
    




    {'n_estimators': [10, 60, 110, 160, 210],
     'max_depth': [5, 15, 25, 35, None],
     'min_samples_split': [0.005, 0.015, 0.025, 0.035],
     'min_samples_leaf': [0.005, 0.015, 0.025, 0.035],
     'max_features': ['sqrt', 'log2']}




```python
def my_roc_auc_score(rfg, X_test,y_test): return metrics.roc_auc_score(y,rfg.predict(X_test))

model_rfg=HalvingGridSearchCV(estimator=rfg,
                             param_grid=params_grid,  
                              cv=3,
                             n_jobs=-1)
model_rfg.fit(X_train,y_train)
```




<style>#sk-container-id-15 {color: black;background-color: white;}#sk-container-id-15 pre{padding: 0;}#sk-container-id-15 div.sk-toggleable {background-color: white;}#sk-container-id-15 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-15 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-15 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-15 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-15 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-15 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-15 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-15 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-15 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-15 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-15 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-15 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-15 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-15 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-15 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-15 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-15 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-15 div.sk-item {position: relative;z-index: 1;}#sk-container-id-15 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-15 div.sk-item::before, #sk-container-id-15 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-15 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-15 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-15 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-15 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-15 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-15 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-15 div.sk-label-container {text-align: center;}#sk-container-id-15 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-15 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-15" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>HalvingGridSearchCV(cv=3,
                    estimator=RandomForestRegressor(n_estimators=10,
                                                    random_state=1),
                    n_jobs=-1,
                    param_grid={&#x27;max_depth&#x27;: [5, 15, 25, 35, None],
                                &#x27;max_features&#x27;: [&#x27;sqrt&#x27;, &#x27;log2&#x27;],
                                &#x27;min_samples_leaf&#x27;: [0.005, 0.015, 0.025,
                                                     0.035],
                                &#x27;min_samples_split&#x27;: [0.005, 0.015, 0.025,
                                                      0.035],
                                &#x27;n_estimators&#x27;: [10, 60, 110, 160, 210]})</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item sk-dashed-wrapped"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-17" type="checkbox" ><label for="sk-estimator-id-17" class="sk-toggleable__label sk-toggleable__label-arrow">HalvingGridSearchCV</label><div class="sk-toggleable__content"><pre>HalvingGridSearchCV(cv=3,
                    estimator=RandomForestRegressor(n_estimators=10,
                                                    random_state=1),
                    n_jobs=-1,
                    param_grid={&#x27;max_depth&#x27;: [5, 15, 25, 35, None],
                                &#x27;max_features&#x27;: [&#x27;sqrt&#x27;, &#x27;log2&#x27;],
                                &#x27;min_samples_leaf&#x27;: [0.005, 0.015, 0.025,
                                                     0.035],
                                &#x27;min_samples_split&#x27;: [0.005, 0.015, 0.025,
                                                      0.035],
                                &#x27;n_estimators&#x27;: [10, 60, 110, 160, 210]})</pre></div></div></div><div class="sk-parallel"><div class="sk-parallel-item"><div class="sk-item"><div class="sk-label-container"><div class="sk-label sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-18" type="checkbox" ><label for="sk-estimator-id-18" class="sk-toggleable__label sk-toggleable__label-arrow">estimator: RandomForestRegressor</label><div class="sk-toggleable__content"><pre>RandomForestRegressor(n_estimators=10, random_state=1)</pre></div></div></div><div class="sk-serial"><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-19" type="checkbox" ><label for="sk-estimator-id-19" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestRegressor</label><div class="sk-toggleable__content"><pre>RandomForestRegressor(n_estimators=10, random_state=1)</pre></div></div></div></div></div></div></div></div></div></div>




```python
model_rfg.best_params_
```




    {'max_depth': 35,
     'max_features': 'log2',
     'min_samples_leaf': 0.005,
     'min_samples_split': 0.005,
     'n_estimators': 110}




```python
rfg1=RandomForestRegressor(max_depth= 35,                         
 min_samples_leaf=0.005,
 min_samples_split= 0.005,
 n_estimators=900)
```


```python
rfg1.fit(X_train,y_train)
```




<style>#sk-container-id-2 {color: black;background-color: white;}#sk-container-id-2 pre{padding: 0;}#sk-container-id-2 div.sk-toggleable {background-color: white;}#sk-container-id-2 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-2 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-2 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-2 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-2 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-2 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-2 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-2 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-2 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-2 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-2 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-2 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-2 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-2 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-2 div.sk-item {position: relative;z-index: 1;}#sk-container-id-2 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-2 div.sk-item::before, #sk-container-id-2 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-2 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-2 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-2 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-2 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-2 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-2 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-2 div.sk-label-container {text-align: center;}#sk-container-id-2 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-2 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-2" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestRegressor(max_depth=35, min_samples_leaf=0.005,
                      min_samples_split=0.005, n_estimators=900)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-2" type="checkbox" checked><label for="sk-estimator-id-2" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestRegressor</label><div class="sk-toggleable__content"><pre>RandomForestRegressor(max_depth=35, min_samples_leaf=0.005,
                      min_samples_split=0.005, n_estimators=900)</pre></div></div></div></div></div>




```python
rfg1_predict=rfg1.predict(X_test)
```


```python
import math
```


```python
rfg1_mse=metrics.mean_squared_error(y_test, rfg1_predict)
rfg1_rmse=math.sqrt(rfg1_mse)
rfg1_mae=metrics.mean_absolute_error(y_test,rfg1_predict)
```


```python
print('MSE is:', round(rfg1_mse,1))
print("RMSE is:", round(rfg1_rmse,1))
print("MAE is:", round(rfg1_mae,1))
print("Accuracy is:", round(rfg1.score(X_test,y_test)*100,1))
```

    MSE is: 32756733273.4
    RMSE is: 180988.2
    MAE is: 90642.8
    Accuracy is: 75.0
    


```python

```
